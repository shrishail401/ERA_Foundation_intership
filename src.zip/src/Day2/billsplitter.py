Total_Bill=float(input("Enter the Total Bill:"))
NOP=int(input("Number of People:"))
Share_per_person=Total_Bill/NOP
print(f"Total Bill:{Total_Bill}. Each person needs to pay:{Share_per_person}")