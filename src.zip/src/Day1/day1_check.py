import sys

print('Setup Complete!')
print("Current python version",sys.version)