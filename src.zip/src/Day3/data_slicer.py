temperatures=[22, 24, 25, 28, 30, 29, 27, 26, 24, 22]
print(temperatures[0])
print(temperatures[-1])
afternoon=temperatures[3:6]
last3=temperatures[-3:]
print("Afternoon peak:",afternoon)
print("Last 3 Hours:",last3)