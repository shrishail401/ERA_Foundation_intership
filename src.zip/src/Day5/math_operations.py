def power(base,exp):
    return base**exp

def average(numbers_list):
    return sum(numbers_list)/len(numbers_list)